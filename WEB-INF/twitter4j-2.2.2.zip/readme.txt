Twittetr4J is a Twitter API binding library for the Java language licensed under Apache License 2.0.

Twitter4J includes software from JSON.org to parse JSON response from the Twitter API. You can see the license term at http://www.JSON.org/license.html

LICENSE.txt - the terms of license of this software
pom.xml - maven parent pom
powered-by-badge - badge
readme.txt - this file
twitter4j-core - core component : support REST and Search API
twitter4j-apache-httpclient-support - optional component adds Apache HttpClient support
twitter4j-examples - examples
twitter4j-media-support - media API support
twitter4j-async - Async API support : depending on twitter4j-core
twitter4j-stream - Streaming API support : depeinding on twitter4j-core and twitter4j-async

Contributors
------------
Adam Samet <asamet at twitter.com> @damnitsamet
Alan Gutierrez <alan at blogometer.com>
Anton Evane <antonevane at gmail.com> @anton_evane
Blake Barnes <blake.barnes at gmail.com>
Bruno Torres Goyanna <bgoyanna at gmail.com> @bgoyanna
Ciaran Jessup <ciaranj at gmail.com> @ciaran_j
Dan Checkoway <dcheckoway at gmail.com>
Dong Wang <dong at twitter.com> @dongwang218
Eric Jensen <ej at twitter.com> @ej
Hitoshi Kunimatsu <hkhumanoid at gmail.com>
Jacob S. Hoffman-Andrews <jsha at twitter.com> @j4cob
Jenny Loomis <jenny at rockmelt.com>
John Corwin <jcorwin at twitter.com> @johnxorz
John Sirois <jsirois at twitter.com> @johnsirois
Julien Letrouit <julien.letrouit at gmail.com> @jletroui
Ludovico Fischer @ludovicofischer
marr-masaaki <marr fiveflavors at gmail.com> @marr
Mocel <docel77 at gmail.com> @Mocel
Nobutoshi Ogata <n-ogata at cnt.biglobe.co.jp> @nobu666
Nicholas Dellamaggiore <nick.dellamaggiore at gmail.com> @nickdella
Perry Sakkaris <psakkaris at gmail.com>
Roberto Estrada <robestradac at gmail.com>
Roy Reshef Roy Reshef <royreshef at gmail.com>
Rui Silva
Rémy Rakic <remy.rakic at gmail.com> @lqd
Takao Nakaguchi <takao.nakaguchi at gmail.com> @takawitter
Tomohisa Igarashi <tm.igarashi at gmail.com>
Will Glozer <will at glozer.net> @ar3te
William Morgan <william at twitter.com> @wm
withgod <noname at withgod.jp> @withgod
Yusuke Yamamoto <yusuke at mac.com> @yusukey
